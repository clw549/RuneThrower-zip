#include "particle.h"
#include <godot_cpp/core/class_db.hpp>

using namespace godot;

void Particle::_bind_methods() {
  ADD_PROPERTY(PropertyInfo(Variant::FLOAT, "speed", PROPERTY_HINT_RANGE, "0,20,0.01"), "set_speed", "get_speed");
  ADD_PROPERTY(PropertyInfo(Variant::FLOAT, "time_left", PROPERTY_HINT_RANGE, "0,20,0.01"), "set_time_left", "get_time_left");
  ClassDB::bind_method(D_METHOD("get_speed"), &Particle::get_speed);
	ClassDB::bind_method(D_METHOD("set_speed", "p_speed"), &Particle::set_speed);
  ClassDB::bind_method(D_METHOD("get_time_left"), &Particle::get_time_left);
	ClassDB::bind_method(D_METHOD("set_time_left", "new_time_left"), &Particle::set_time_left);
}

Particle::Particle() {
  time_left = 2.5;
  speed = 10;
}

Particle::~Particle () {
  //cleanup
}

void Particle::_process(double delta) {

  time_left = time_left - delta;
}

double Particle::get_time_left() const {
  return time_left;
}

void Particle::set_time_left(double const new_time_left) {
  //no negative numbers
  if (new_time_left < 0) time_left = 0;
  time_left = new_time_left;
}

double Particle::get_speed() const {
  return speed;
}

void Particle::set_speed(double const n_speed) {
  speed = n_speed;
}