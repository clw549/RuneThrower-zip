#include "bouncy2D.h"
#include <godot_cpp/core/class_db.hpp>

using namespace godot;

void Bouncy2D::_bind_methods() {
  ADD_PROPERTY(PropertyInfo(Variant::FLOAT, "bounces", PROPERTY_HINT_RANGE, "0,20,0.01"), "set_bounces", "get_bounces");
  ADD_PROPERTY(PropertyInfo(Variant::FLOAT, "bounceSpeed", PROPERTY_HINT_RANGE, "0,20,0.01"), "set_bounce_speed", "get_bounce_speed");

  ADD_PROPERTY(PropertyInfo(Variant::FLOAT, "time_left", PROPERTY_HINT_RANGE, "0,20,0.01"), "set_time_left", "get_time_left");
  ClassDB::bind_method(D_METHOD("get_bounces"), &Bouncy2D::get_bounces);

	ClassDB::bind_method(D_METHOD("set_bounces", "new_bounces"), &Bouncy2D::set_bounces);

  ClassDB::bind_method(D_METHOD("get_bounce_speed"), &Bouncy2D::get_bounce_speed);

	ClassDB::bind_method(D_METHOD("set_bounce_speed", "new_bounceSpeed"), &Bouncy2D::set_bounce_speed);

  ClassDB::bind_method(D_METHOD("bounce"), &Bouncy2D::bounce);

  ClassDB::bind_method(D_METHOD("get_time_left"), &Bouncy2D::get_time_left);
	ClassDB::bind_method(D_METHOD("set_time_left", "new_time_left"), &Bouncy2D::set_time_left);

  ClassDB::bind_method(D_METHOD("time_left_countdown", "delta"), &Bouncy2D::time_left_countdown);

  ClassDB::bind_method(D_METHOD("set_pos", "newPos"), &Bouncy2D::set_pos);
  ClassDB::bind_method(D_METHOD("set_vel", "newVel"), &Bouncy2D::set_vel);

  ClassDB::bind_method(D_METHOD("set_speed_reset", "new_reset"), &Bouncy2D::set_speed_reset);

  ClassDB::bind_method(D_METHOD("set_rot", "new_rot"), &Bouncy2D::set_rot);


	ADD_SIGNAL(MethodInfo("bounceless", PropertyInfo(Variant::OBJECT, "node")));
  ADD_SIGNAL(MethodInfo("bounce", PropertyInfo(Variant::OBJECT, "node")));
  ADD_SIGNAL(MethodInfo("time_out", PropertyInfo(Variant::OBJECT, "node")));
}
//sadly this could be easily done in scripting, 
// however I need the assignment done
// and I have no better Ideas yet.
// this is not changing even if I get one.
// the signals are cool though :)

// my 2 features are the time left and bouncy features of this class
// one ensures that the projectile eventually times our instead of existing 
// forever. this ensures that they do not come back to spawn, weird bug.
Bouncy2D::Bouncy2D() {
  bounces = 2;
  bounceSpeed = 200;
  speedReset = 200;
  time_left = 10;
  position = Vector2(0, 0);
  velocity = Vector2(0, 0);
  rotation = 0;

  std::srand(std::time({}));//seed the random number generator
}

Bouncy2D::~Bouncy2D () {
  //cleanup
}

void Bouncy2D::_process(double delta) {
	position += velocity*delta*bounceSpeed;
	bounceSpeed /= 61*delta;
	rotation += bounceSpeed*delta;
	time_left_countdown(delta);
  set_position(position);
  set_rotation(rotation);
}

int Bouncy2D::get_bounces() const {
  return bounces;
}

void Bouncy2D::set_bounce_speed(double const new_bounceSpeed) {
  bounceSpeed = new_bounceSpeed;
}

double Bouncy2D::get_bounce_speed() const {
  return bounceSpeed;
}

void Bouncy2D::set_bounces(int const new_bounces) {
  bounces = new_bounces;
}

// we need areas and collision detection to do these bounces :(
// sprite 2D does not have this functionality on its own
int Bouncy2D::bounce() {
  bounces -= 1;
  if (bounces < 0) {
    emit_signal("bounceless", this);
  }
  else {
    set_vel(Vector2((std::rand()%3)-2, (std::rand()%3)-2));
  }
  return bounces;
}

double Bouncy2D::get_time_left() const {
  return time_left;
}

void Bouncy2D::set_time_left(double const new_time_left) {
  //no negative numbers
  if (new_time_left < 0) time_left = 0;
  time_left = new_time_left;
}

float Bouncy2D::time_left_countdown(float const delta) {
  time_left -= delta;
  if (time_left <= 0) {
    emit_signal("time_out", this);
  }
  return time_left;
}

void Bouncy2D::set_pos(Vector2 newPos) {
  position = newPos;
}

void Bouncy2D::set_vel(Vector2 newVel) {
  velocity = newVel;
}

void Bouncy2D::set_speed_reset(double const new_reset) {
  speedReset = new_reset;
}

void Bouncy2D::set_rot(float const new_rot) {
  rotation = new_rot;
}