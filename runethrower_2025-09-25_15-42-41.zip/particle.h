#ifndef PARTICLE_H
#define PARTICLE_H

#include <godot_cpp/classes/sprite2d.hpp>

namespace godot {

class Particle : public Sprite2D {
	GDCLASS(Particle, Sprite2D)

private:
  double time_left;
  double speed;

protected:
	static void _bind_methods();

public:
	Particle();
	~Particle();

  void _process(double delta) override;


  void set_time_left(const double new_time_left);
  double get_time_left() const;

  double get_speed () const;
  void set_speed(const double n_speed);
};

}

#endif