#ifndef BOUNCY2D
#define BOUNCY2D

#include <godot_cpp/classes/sprite2d.hpp>
#include <cstdlib>

namespace godot {

class Bouncy2D : public Sprite2D {
	GDCLASS(Bouncy2D, Sprite2D)

private:
  int bounces;
  double bounceSpeed;
  double time_left;
  Vector2 velocity;
  Vector2 position;
  float rotation;
  double speedReset;

protected:
	static void _bind_methods();

public:
	Bouncy2D();
	~Bouncy2D();

  void _process(double delta) override;


  void set_bounces(const int new_bounces);
  int get_bounces() const;

  double get_bounce_speed () const;
  void set_bounce_speed(const double new_bounceSpeed);

  void set_time_left(const double new_time_left);
  double get_time_left() const;

  int bounce();

	float time_left_countdown(float const delta);

  void set_pos(Vector2 newPos);
  void set_vel(Vector2 newVel);

  void set_speed_reset(double const new_reset);

  void set_rot(float const new_rot);

};

}

#endif